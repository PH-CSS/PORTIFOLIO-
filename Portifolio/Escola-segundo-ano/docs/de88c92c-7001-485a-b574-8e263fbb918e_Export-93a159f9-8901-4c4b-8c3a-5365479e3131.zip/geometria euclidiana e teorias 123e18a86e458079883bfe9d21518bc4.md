# geometria euclidiana e teorias

Criado: 18 de outubro de 2024 12:54
Aula: MATEMÁTICA
Tipo: Seminário
Materiais: https://pt.khanacademy.org/math/geometry/hs-geo-transformations/hs-geo-intro-euclid/v/euclid-as-the-father-of-geometry
Revisado: No
Data de entrega: 19 de outubro de 2024 → 1 de novembro de 2024
subMateria: Matriz

- translação
- reflexão
- rotação
- escala
- criptografia
- teo. binet
- teo. jacobi
- teo. laplace
- regra de cramer

**Título**: Transformações Geométricas e Conceitos Matemáticos Aplicados

**Introdução**

Este trabalho aborda os principais conceitos matemáticos e de criptografia que fundamentam a análise de transformações geométricas, algoritmos e teorias que são amplamente utilizados em matemática aplicada. A compreensão desses temas é essencial para o desenvolvimento de competências nas áreas de geometria, álgebra e criptografia.

**1. Transformações Geométricas**

1.1 **Translação**

A translação é uma transformação geométrica que

**move todos os pontos de uma figura ou espaço, na mesma distância e direção**

. É uma isometria que desloca a figura original de acordo com um vetor, ou seja, um sentido, direção e comprimento.

**A translação conserva:**

- A direção e o comprimento dos segmentos de reta
- As amplitudes dos ângulos

Um exemplo de translação é mover uma imagem para um novo local.

Para descrever uma translação algebricamente, é possível usar as coordenadas. Por exemplo, se um ponto é transladado 5 unidades para a esquerda e 3 unidades para cima, a translação é descrita como (x-5, y+3).

A simetria de translação é quando uma figura é movida sem rotacionar, em qualquer direção.

1.2 **Reflexão**

Reflexão é uma transformação que produz uma imagem espelhada de uma figura em relação a uma linha (plano na geometria tridimensional). Esse conceito é fundamental na simetria e pode ser representado por matrizes, que invertem as coordenadas dependendo do eixo de reflexão.

1.3 **Rotação**

A rotação de uma imagem consiste em girá-la em relação a um ponto no plano, chamado de centro de rotação. Para realizar a rotação de uma figura, devemos considerar a orientação do giro (sentido horário ou anti-horário), e a medida, em graus, do ângulo de rotação.

**Exemplo**

O triângulo ABC sofreu um giro no sentido anti-horário de um ângulo de rotação de 45°. O centro de rotação é o ponto A, que por isto, permanece fixo.

1.4 **Escala**

Escala refere-se ao aumento ou redução proporcional de uma figura ou objeto, mantendo a forma original. Esta transformação é amplamente utilizada em diversas aplicações, como gráficos e arquitetura, e pode ser representada matematicamente por multiplicação de matrizes.

A escala em um mapa ou desenho é uma constante, relacionando as dimensões apresentadas entre o desenho e o objeto real representado por ele.

**Escala = medida da representação : medida no real**

Essas unidades devem sempre está na mesma unidade de medida.

Observe o exemplo abaixo:

Se um mapa apresenta uma escala de 1:100, significa que a cada 1 cm no mapa á equivalente a 100 cm na área real, ou seja, 1 metro.

**2. Criptografia**

1. Introdução à criptografia: A criptografia é uma técnica usada para proteger informações, tornando-as ilegíveis para pessoas não autorizadas.
2. Tipos de criptografia: Existem dois tipos principais - simétrica (usa a mesma chave para codificar e decodificar) e assimétrica (usa um par de chaves, pública e privada).
3. As aplicações da criptografia são vastas, incluindo segurança de comunicações, proteção de dados pessoais e autenticação digital.

  

**3. Teoremas Matemáticos**

3.1 **Teorema de Binet**

"O que é o teorema de Binet?
O teorema de Binet é usado para facilitar o cálculo de determinante de um produto matricial. Acontece que calcular a multiplicação entre duas matrizes nem sempre é uma tarefa fácil, então, o teorema de Binet mostra um caminho menos árduo para se obter esse determinante. Utilizando esse teorema, em vez de calcular o produto matricial, calculamos o determinante de cada uma das matrizes, e depois multiplicamos a resposta.

Teorema de Binet
O teorema de Binet diz que:

Dadas A e B duas matrizes quadradas de mesma ordem, então, temos que:

det(A·B) = det(A)·det(B)

Observação: conhecemos como matriz quadrada a matriz que possui o mesmo número de linhas e colunas, e o cálculo do determinante só é feito em matrizes quadradas, portanto, é importante que as duas matrizes sejam quadradas de mesma ordem.

Não pare agora... Tem mais depois da publicidade ;)

Exemplo:

Conhecendo as matrizes A e B, a seguir, mostre que det(A) · det(B) = det(A · B).

![image.png](image.png)

Calculando separadamente, temos que:

det(A) = 1 · 4 – 2 · 3 = 4 – 6 = -2

det(B) = 1 · 1 – 3 · 2 = 1 – 6 = -5

Então, o produto det(A) · det(B) = (-2) · (-5) = 10.

Agora, vamos encontrar o produto matricial C = A · B.

Realizando a multiplicação entre as matrizes, temos que:

C11 = 1 · 1 + 2 · 2 = 1 + 4 = 5

C12 = 1 · 3 + 2 · 1 = 3 + 2 = 5

C21 = 3 · 1 + 4 · 2 = 3 + 8 = 11

C22 = 3 · 3 + 4 · 1 = 9 + 4 = 13

Então, a matriz C é a matriz a seguir:

![image.png](image%201.png)

Calculando seu determinante, temos que:

det(C) = det(A · B) = 5 · 13 – 11 · 5 = 65 – 55 = 10

Então, podemos concluir que, de fato, det(A) · det(B) = det(A · B)."

([https://brasilescola.uol.com.br/matematica/teorema-binet.htm#O+que+é+o+teorema+de+Binet%3F](https://brasilescola.uol.com.br/matematica/teorema-binet.htm#O+que+%C3%A9+o+teorema+de+Binet%3F))

3.2 **Teorema de Jacobi**

Esse teorema diminui os valores dos elementos de uma matriz quadrada, facilitando os cálculos. Vejamos seu conceito:

*“Seja **A** uma matriz quadrada, se multiplicarmos todos os elementos de uma fila (linha ou coluna) por um mesmo número, e somarmos os resultados dos elementos aos seus correspondentes de outra fila (linha ou coluna), obteremos outra matriz B. Entretanto, podemos afirmar que o det A = det B”.*

Atente-se ao simples detalhe de somar os elementos aos seus correspondentes de outra fila, ou seja, se multiplicarmos uma linha por um número qualquer (k), deveremos somar o resultado (elemento x k) pelos elementos de outra linha. Vejamos um exemplo para melhor compreender esse teorema.

Exemplo:

***Aplique o Teorema de Jacobi na matriz A.***

![https://static.mundoeducacao.uol.com.br/mundoeducacao/conteudo/images/tj1.jpg](https://static.mundoeducacao.uol.com.br/mundoeducacao/conteudo/images/tj1.jpg)

Vamos aplicar o teorema de Jacobi na matriz A, multiplicando a primeira linha por (**-2**) e somando os resultados à 2ª linha. Com isso, obteremos outra matriz:

![https://static.mundoeducacao.uol.com.br/mundoeducacao/conteudo/tj2.jpg](https://static.mundoeducacao.uol.com.br/mundoeducacao/conteudo/tj2.jpg)

Veja que os elementos da segunda linha ficaram com valores menores, ou seja, em determinadas situações em que se tem uma matriz com uma linha que possui elementos com valores muito altos, pode-se utilizar o teorema de Jacobi, até mesmo para eliminar certos elementos (deixar os elementos com valor nulo, ou seja, iguais a zero).

Esse processo é totalmente semelhante ao de resolução de sistemas lineares, no qual se multiplica uma equação por um número e soma-se essa equação obtida pela multiplicação à outra. Trata-se de um processo baseado no teorema de Jacobi.

O Teorema de Jacobi é um princípio da álgebra linear que afirma que o determinante de uma matriz quadrada A, quando calculado por meio de cofatores ao longo de qualquer linha ou coluna, resulta no mesmo valor. Isso pode ser aplicado para matrizes de qualquer ordem, incluindo matrizes 3×3.

### Determinante de uma Matriz 3×33 \times 33×3 Usando Expansão em Cofatores (Fórmula de Jacobi)

Para uma matriz 3×3 como:

![image.png](image%202.png)

​

O determinante de A pode ser calculado expandindo pelos cofatores de qualquer linha ou coluna. Aqui, vamos fazer a expansão pela primeira linha para simplificar.

### Passo a Passo do Cálculo do Determinante Usando a Expansão por Cofatores

A fórmula do determinante para a matriz 3×3 pela primeira linha é:

det⁡(A)=a⋅C11+b⋅C12+c⋅C13

onde C{11}, C{12}, e C{13}são os cofatores dos elementos a, b e c, respectivamente.

### Calculando Cada Cofator

Para cada elemento da primeira linha (a, b, c), precisamos do **menor complementar** e do **cofator**:

1. **Cofator de a:**
    - Menor complementar de a: remova a primeira linha e a primeira coluna, restando a submatriz:
    
    ![image.png](image%203.png)
    
    - Determinante do menor complementar:
    M11​=e⋅i−f⋅h
    - Cofator de a: C11=(−1)^(1+1) ⋅ M11=e⋅i−f⋅h
        
        C11=(−1)^(1+1) ⋅ M11=e⋅i−f⋅h
        
2. **Cofator de b:**
    - Menor complementar de b: remova a primeira linha e a segunda coluna, restando:
    
    ![image.png](image%204.png)
    
    - Determinante do menor complementar:
    M12​=d⋅i−f⋅g
    - Cofator de b: C12=(−1)^(1+2)⋅M12=−(d⋅i−f⋅g)
3. **Cofator de c:**
    - Menor complementar de c: remova a primeira linha e a terceira coluna, restando:
    
    ![image.png](image%205.png)
    
    - Determinante do menor complementar:
    M13​=d⋅h−e⋅g
    - Cofator de c: C13=(−1)^(1+3)⋅M13=d⋅h−e⋅g
        
        

### Somando os Termos para o Determinante

Substituímos os cofatores na fórmula da expansão:

det⁡(A)=a⋅(e⋅i−f⋅h)−b⋅(d⋅i−f⋅g)+c⋅(d⋅h−e⋅g)

Essa expressão é o determinante da matriz 3×3 pela expansão em cofatores na primeira linha, um processo viabilizado pelo Teorema de Jacobi.

### Aplicação do Teorema de Jacobi em Sistemas e Autovalores

Em geral, o Teorema de Jacobi também se aplica em contextos avançados, como ao calcular derivadas de determinantes (em análise de sistemas dinâmicos) e no estudo de autovalores, onde se utiliza para definir propriedades importantes sobre a matriz e seus valores característicos, garantindo estabilidade e relações com os determinantes dos menores complementares.

3.3 **Teorema de Laplace**

O **Teorema de Laplace** é uma extensão do método de cálculo do determinante de uma matriz usando expansão em cofatores. Ele permite calcular o determinante de uma matriz de ordem maior usando o determinante de submatrizes menores, o que é particularmente útil para matrizes de ordem n×nn \times nn×n com n>2n > 2n>2. Para entender esse teorema, vamos definir alguns conceitos importantes: **menor complementar** e **cofator**.

### Conceitos Básicos

1. **Menor Complementar**:
    
    O menor complementar M{ij} de um elemento a{ij} de uma matriz A é o determinante da submatriz que resulta de A ao remover a linha i e a coluna j que contém a{ij}.
    
    ![image.png](image%206.png)
    

![image.png](image%207.png)

**Cofator**:

O cofator C{ij} de um elemento a{ij} é calculado a partir do menor complementar M{ij}, mas inclui um fator de sinal (−1)^i+j:

![image.png](image%208.png)

Esse fator alternado garante que cada elemento tenha um sinal específico na expansão do determinante.

### Teorema de Laplace

O Teorema de Laplace afirma que o determinante de uma matriz n×nn \times nn×n pode ser calculado pela soma dos produtos dos elementos de qualquer linha (ou coluna) pelos seus cofatores correspondentes. Em outras palavras, podemos escolher qualquer linha ou coluna da matriz para fazer a expansão, e o determinante será o mesmo.

"Ilustração algébrica:

![image.png](image%209.png)

Vejamos um exemplo:

Calcule o determinante da matriz C, utilizando o teorema de Laplace:

![image.png](image%2010.png)

De acordo com o teorema de Laplace, devemos escolher uma fila (linha ou coluna) para calcular o determinante. Vamos utilizar a primeira coluna:

![image.png](image%2011.png)

Precisamos encontrar os valores dos cofatores:

![image.png](image%2012.png)

![image.png](image%2013.png)

![image.png](image%2014.png)

Sendo assim, pelo teorema de Laplace, o determinante da matriz C é dado pela seguinte expressão:

![image.png](image%2015.png)

Note que não foi preciso calcular o cofator do elemento da matriz que era igual a zero, afinal, ao multiplicarmos o cofator, o resultado seria zero de qualquer forma. Diante disso, quando nos depararmos com matrizes que possuem muitos zeros em alguma de suas filas, a utilização do teorema de Laplace se torna interessante, pois não será necessário calcular diversos cofatores.

Vejamos um exemplo deste fato:

Calcule o determinante da matriz B, utilizando o teorema de Laplace:

![image.png](image%2016.png)

Veja que a segunda coluna é a fila que possui maior quantidade de zeros, portanto utilizaremos esta fila para calcular o determinante da matriz através do teorema de Laplace.

![image.png](image%2017.png)

Portanto, para determinar o determinante da matriz B, basta encontrar o cofator A22.

![image.png](image%2018.png)

Sendo assim, podemos finalizar os cálculos do determinante:

det B = (- 1) . (- 65) = 65"

Vale lembrar que o **Teorema de Jacobi** e o **Teorema de Laplace** estão, de fato, interligados em muitos aspectos, especialmente no contexto de **expansão de determinantes por cofatores** e na **análise de matrizes.**

# Pontos em comum a se destacar :

- **Expansão por Cofatores**:
    - Ambos os teoremas tratam da ideia de expandir o determinante de uma matriz ao longo de uma linha ou coluna usando cofatores. O Teorema de Laplace formaliza esse processo, garantindo que o determinante pode ser obtido expandindo ao longo de qualquer linha ou coluna e que o resultado será o mesmo.
    - Jacobi estuda propriedades de determinantes e cofatores, inclusive estabelecendo relações entre eles e aplicando-as a várias transformações e sistemas.
- **Menores e Cofatores**:
    - O Teorema de Jacobi é muitas vezes usado em contextos mais avançados que envolvem menores complementares e cofatores, como ao analisar autovalores e sistemas dinâmicos. O Teorema de Laplace nos dá a base, ao definir o uso de cofatores no cálculo do determinante.
    - Jacobi amplia esse conceito, explorando como menores e cofatores se relacionam com propriedades de autovalores e com a estabilidade de matrizes.
- **Aplicação em Matrizes e Sistemas**:
    - Ambos teoremas são usados para resolver sistemas lineares, encontrar determinantes e analisar o comportamento das matrizes. O Teorema de Laplace é essencial para o cálculo direto de determinantes, enquanto o Teorema de Jacobi é usado em teoremas mais avançados, como o **Teorema de Jacobi sobre autovalores**, para estudar a estrutura interna de uma matriz.

3.4 **Regra de Cramer**

A Regra de Cramer é um método para resolver sistemas de equações lineares utilizando determinantes. Ela é particularmente útil para sistemas de pequena dimensão, oferecendo uma solução direta para variáveis com base na divisão de determinantes.

"O que é a regra de Cramer?
A regra de Cramer foi uma estratégia desenvolvida pelo matemático Gabriel Cramer, que tinha como objetivo encontrar um método para facilitar a busca dos valores que são solução de um sistema linear que possuem o mesmo número de equações e incógnitas. Um sistema linear é um conjunto de n equações que estão relacionadas entre si. Vejamos um exemplo algébrico de sistema linear 3x3.

![image.png](image%2019.png)

A regra de Cramer determina que:

![image.png](image%2020.png)

D, Dx, Dy e Dz são determinantes de matrizes formadas com o sistema.

D → é o determinante da matriz formada pelos coeficientes das incógnitas;

Dx → é o determinante da matriz formada pelos coeficientes substituindo a coluna dos coeficientes de x pelos termos independentes que estão depois da igualdade;

Dy → é o determinante da matriz formada pelos coeficientes substituindo a coluna dos coeficientes de y pelos termos independentes que estão depois da igualdade;

Dz → é o determinante da matriz formada pelos coeficientes substituindo a coluna dos coeficientes de z pelos termos independentes que estão depois da igualdade.

Para aplicar a regra de Cramer, é necessário retirar desse sistema linear quatro matrizes 3x3, das quais calcularemos o determinante.

A primeira delas é a matriz formada por cada um dos coeficientes de x, y e z. Seu determinante é representado por D.

![image.png](image%2021.png)

Já nas demais matrizes, vamos substituir cada uma das colunas pela coluna dos valores que estão depois da igualdade. Por exemplo, Dx terá na sua primeira coluna, onde ficavam os coeficientes de x, os valores de d1, d2 e d3. Em Dy e Dz, isso acontecerá respectivamente nas 2ª e 3ª colunas:

![image.png](image%2022.png)

Após calcular os 4 determinantes, é possível obter a razão entre eles, para encontrarmos o valor de cada uma das variáveis.

Observação: Como vamos calcular a razão entre os determinantes, e o denominador sempre será o determinante D, para encontrar os valores para as incógnitas é necessário que D ≠ 0. Caso o determinante D seja igual a 0, significa que ou o sistema é impossível, ou seja, não possui soluções, ou o sistema é possível indeterminando, ou seja, possui infinitas soluções.

Leia também: Teorema de Binet – processo prático para a multiplicação de matrizes

Regra de Cramer em um sistema 2x2

Vejamos, a seguir, a aplicação da regra de Cramer para encontrar as soluções de um sistema linear 2x2.

![image.png](image%2023.png)

Resolução:

Como esse sistema é 2x2, encontraremos os valores de: D, Dx e Dy.

![image.png](image%2024.png)

Calculando o determinante, temos que:

D = 2 · 2 – 4 · 3

D = 4 – 12

D = – 8

Agora, calcularemos Dx:

![image.png](image%2025.png)

Dx = 7 · 2 – 10 · 3

Dx = 14 – 30

Dx = – 16

Calcularemos também Dy:

![image.png](image%2026.png)

Dy = 2 · 10 – 7 · 4

Dy = 20 – 28

Dy = – 8

Em seguida, calcularemos os valores de x e de y:

Então, os valores de x e y que satisfazem esse sistema de equação são x = 2 e y = 1.

Regra de Cramer para um sistema 3x3
Agora, vejamos um exemplo da aplicação da regra de Cramer para encontrar as soluções de um sistema de equação 3x3.

Exemplo:

![image.png](image%2027.png)

Resolução:

Primeiramente, calcularemos o valor de D:

![image.png](image%2028.png)

D = 1 · 2 · 3 + (– 3) · 1 · 2 + 5 · 1 · (– 1) – [5 · 2 · 2 + 1 · 1 · (– 1) + (– 3) · 1 · 3]

D = 6 – 6 – 5 – [20 – 1 – 9]

D = – 5 – 10

D = – 15

Agora, calcularemos o valor de Dx:

![image.png](image%2029.png)

Dx = 1 · 2 · 3 + (– 3) · 1 · 10 + 5 · 12 · (– 1) – [5 · 2 · 10 + 1 · 1 · (– 1) + (– 3) · 12 · 3]

Dx = 6 – 30 – 60 – [100 – 1 – 108]

Dx = – 84 + 9

Dx = – 75

Calculando Dy:

![image.png](image%2030.png)

Dy = 1 · 12 · 3 + 1 · 1 · 2 + 5 · 1 · 10 – [5 · 12 · 2 + 1 · 1 · 10 + 1 · 1 · 3]

Dy = 36 + 2 + 50 – [120 + 10 + 3]

Dy = 88 – 133

Dy = – 45

Calculando Dz:

![image.png](image%2031.png)

Dz = 1 · 2 · 10 + (– 3) · 12 · 2 + 1 · 1 · (– 1) – [1 · 2 · 2 + 1 · 12 · (– 1) + (– 3) · 1 · 10

Dz = 20 – 72 – 1 – [4 – 12 – 30]

Dz = – 53 +38

Dz = – 15

Agora podemos encontrar os valores de x, y e z:

![image.png](image%2032.png)

**Conclusão**

Os conceitos matemáticos e geométricos abordados são fundamentais para entender tanto a teoria quanto a aplicação prática das transformações e sistemas de equações. Compreender esses temas aprimora a capacidade de resolver problemas matemáticos complexos e de realizar análises precisas em diversas áreas científicas.

**Referências**

1. Translação, reflexão, rotação:
- [https://www.todamateria.com.br/transformacoes-geometricas/](https://www.todamateria.com.br/transformacoes-geometricas/#:~:text=Ao%20conservar%20as%20formas%2C%20ou,um%20ponto%2C%20ser%C3%A1%20uma%20rota%C3%A7%C3%A3o)
1. Escala:
- [https://proenem.com.br/enem/matematica/geometria-plana-semelhanca-e-escala/#:~:text=Escala %3D medida da representação %3A medida no real&text=Se um mapa apresenta uma,%2C ou seja%2C 1 metro](https://proenem.com.br/enem/matematica/geometria-plana-semelhanca-e-escala/#:~:text=Escala%20%3D%20medida%20da%20representa%C3%A7%C3%A3o%20%3A%20medida%20no%20real&text=Se%20um%20mapa%20apresenta%20uma,%2C%20ou%20seja%2C%201%20metro)
1. Criptografia:
- ([https://www.youtube.com/watch?v=qHFbuXpz7e4](https://www.youtube.com/watch?v=qHFbuXpz7e4) / [google cloud](https://cloud.google.com/learn/what-is-encryption?hl=pt-BR))
1. Teorema de Binet:
- ([https://brasilescola.uol.com.br/matematica/teorema-binet.htm#O+que+é+o+teorema+de+Binet%3F](https://brasilescola.uol.com.br/matematica/teorema-binet.htm#O+que+%C3%A9+o+teorema+de+Binet%3F))
1. Teorema de Jacobi:
- ([https://mundoeducacao.uol.com.br/matematica/teorema-jacobi.htm](https://mundoeducacao.uol.com.br/matematica/teorema-jacobi.htm) / [https://www.khanacademy.org/math/linear-algebra](https://www.khanacademy.org/math/linear-algebra))
1. Teorema de Laplace:
- ([https://brasilescola.uol.com.br/matematica/teorema-laplace.htm](https://brasilescola.uol.com.br/matematica/teorema-laplace.htm) / [https://www.youtube.com/watch?v=726AOpEEXrw](https://www.youtube.com/watch?v=726AOpEEXrw))
1. Regra de Cramer:
- ([https://brasilescola.uol.com.br/matematica/regra-cramer.htm](https://brasilescola.uol.com.br/matematica/regra-cramer.htm) / [https://www.youtube.com/watch?v=-tdj_vMekdg](https://www.youtube.com/watch?v=-tdj_vMekdg))

Infelizmente, não posso criar ou enviar arquivos Word diretamente. No entanto, posso sugerir como você pode converter este documento Notion em um arquivo Word:

1. Exporte o conteúdo da página Notion:
- Clique nos três pontos (...) no canto superior direito da página
- Selecione "Exportar"
- Escolha o formato "Markdown & CSV"
- Clique em "Exportar"
1. Converta o arquivo Markdown para Word:
- Abra o Microsoft Word
- Vá para "Arquivo" > "Abrir"
- Selecione o arquivo Markdown exportado
- Word deve converter automaticamente o conteúdo para o formato do Word
1. Formate o documento conforme necessário:
- Ajuste estilos, fontes e layout para melhorar a aparência
- Verifique se imagens e links foram transferidos corretamente

Alternativamente, você pode copiar e colar o conteúdo diretamente da página Notion para um novo documento Word, mas isso pode requerer mais formatação manual.